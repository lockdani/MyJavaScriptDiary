## Workshop 2: Realizando a Migração da Base de Dados Local para o CosmosDb

[![bit-azure.png](https://i.postimg.cc/ZKwS8SHj/bit-azure.png)](https://postimg.cc/vcxkyCp6)

Nesse workshop vocês aprenderão a como realizar a migração da base de dados local, nesse caso do MongoDb, para o banco NOSQL: CosmosDb em poucos minutos para a arquitetura Serverless fazendo uso do Azure Functions.

## Agenda 

- **[O que é CosmosDb?]()**
- **[Workshop 2 - Realizando a Migração da Base de Dados local para CosmosDb]()**
