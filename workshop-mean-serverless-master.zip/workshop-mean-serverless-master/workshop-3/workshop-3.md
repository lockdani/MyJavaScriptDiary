## Workshop 3: Realizando o Deploy da Aplicação e das Funções ao Azure via Visual Studio Code

[![bit-azure.png](https://i.postimg.cc/ZKwS8SHj/bit-azure.png)](https://postimg.cc/vcxkyCp6)

Nesse workshop vocês aprenderão a como realizar o deploy de uma aplicação MEAN e das Funções criadas no workshop 2 usando somente o Visual Studio Code.

## Agenda 

- **[O que é Azure Web App Service?]()**
- **[O que é Azure Storage Account]()**
- **[Workshop 3 - Realizando o Deploy via Visual Studio Code]()**
- **[Palavras Finais]()**
